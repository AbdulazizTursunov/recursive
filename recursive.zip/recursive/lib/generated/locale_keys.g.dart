// DO NOT EDIT. This is code generated via package:easy_localization/generate.dart

abstract class  LocaleKeys {
  static const Ok = 'Ok';
  static const Cansel = 'Cansel';
  static const Editing = 'Editing';
  static const Unlist_folders = 'Unlist_folders';
  static const Add_folder = 'Add_folder';
  static const name = 'name';
  static const Added = 'Added';

}
