package com.example.recursive

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
